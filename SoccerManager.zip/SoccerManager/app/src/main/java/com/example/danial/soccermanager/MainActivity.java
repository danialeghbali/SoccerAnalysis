package com.example.danial.soccermanager;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class MainActivity extends AppCompatActivity {

    public static int width,hight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final DrawPlayer drawPlayer=findViewById(R.id.drawPlayer);

       TextView txt=findViewById(R.id.textView);
       txt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               startActivity(new Intent(MainActivity.this,Details.class));
           }
       });


        DisplayMetrics disp=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(disp);
        width=disp.widthPixels;
        hight=disp.heightPixels;

        Socket socket = null;
        try {
            socket = IO.socket("http://10.0.2.2:1874");

            final Socket finalSocket = socket;
            socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {

            @Override
            public void call(Object... args) {
                finalSocket.emit("mobile", "mobile connected");
              //  socket.disconnect();
            }

        }).on("event", new Emitter.Listener() {

            @Override
            public void call(final Object... args) {

              runOnUiThread(new Runnable() {
                  @Override
                  public void run() {

                          String data = (String) args[0];
                          // get the extra data from the fired event and display a toast
                          //Toast.makeText(ChatBoxActivity.this,data,Toast.LENGTH_SHORT).show();
                             String[] temp=data.trim().split("-");
                          //if(temp.length>1)
                          //((TextView) findViewById(R.id.textView)).setText(data);
                            if(temp.length>1)
                               drawPlayer.refreshScreen(Float.parseFloat(temp[0]),Float.parseFloat(temp[1]));

                  }
              });


            }

        }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {

            @Override
            public void call(Object... args) {}

        });
        socket.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

}
