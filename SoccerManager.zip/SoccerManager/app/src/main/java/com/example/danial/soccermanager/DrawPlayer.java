package com.example.danial.soccermanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

public class DrawPlayer extends View {
    static float x,y;

    public DrawPlayer(Context context) {
        super(context);
    }

    public DrawPlayer(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DrawPlayer(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paint=new Paint();
        paint.setColor(Color.RED);

        if(x!=0 && y!=0)
        canvas.drawCircle(x,y,30,paint);


    }

    public void refreshScreen(float x,float y){
        x=(x * MainActivity.width)/640;
        y=(y * MainActivity.hight)/480;
        this.x=x;
        this.y=y;
        this.postInvalidate();
        //invalidate();
    }
}
