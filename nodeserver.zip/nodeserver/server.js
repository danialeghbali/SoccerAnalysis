var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var net = require('net');

var HOST = '127.0.0.1';
var PORT = 1875;
var t="";
app.get('/', function(req, res){
  res.send("Danial Server Run with data "+t);
  io.emit("event",t);
});

io.on('connection', function(socket){
  console.log('a user connected');
  socket.on('socc', function(){
    
  });
});

net.createServer(function(sock) {
    
  // We have a connection - a socket object is assigned to the connection automatically
  console.log('CONNECTED: ' + sock.remoteAddress +':'+ sock.remotePort);

  // Add a 'data' event handler to this instance of socket
  sock.on('data', function(data) {
      
     // console.log('DATA ' + sock.remoteAddress + ': ' + data);
      t=data+"";
      io.emit("event",t);
      // Write the data back to the socket, the client will receive it as data from the server
     // sock.write('You said "' + data + '"');
      
  });
  sock.on('mobile', function(data) {
      
    // console.log('DATA ' + sock.remoteAddress + ': ' + data);
    // t=data.toString();
     // Write the data back to the socket, the client will receive it as data from the server
    // sock.write('You said "' + data + '"');
     
 });
  // Add a 'close' event handler to this instance of socket
  sock.on('close', function(data) {
      console.log('CLOSED: ' + sock.remoteAddress +' '+ sock.remotePort);
  });
  
}).listen(PORT, HOST);

console.log('socket listening on ' + HOST +':'+ PORT);


http.listen(1874, function(){
  console.log('server on :1874');
});