#ifndef MYSOCKET_H
#define MYSOCKET_H
int connect(char *);
int sendData(int,int);
int shutDown();
void test();
#endif