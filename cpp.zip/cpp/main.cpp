#include "mysocket.h"
#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>  // cv::Canny()
#include <iostream>
#include <future>

using namespace cv;
using std::cout; using std::cerr; using std::endl;

int main(int, char**)
{
     VideoCapture cap(0); //capture the video from webcam

    if ( !cap.isOpened() )  
    {
         cout << "Cannot open the web cam" << endl;
         return -1;
    }

   
connect("127.0.0.1");

    namedWindow("HSV", CV_WINDOW_AUTOSIZE); 

  int iLowH =170;//0;;
 int iHighH =179;//10;

  int iLowS = 150;//98;; 
 int iHighS = 255;

  int iLowV =60;// 160;
 int iHighV = 255;


 createTrackbar("LowH", "HSV", &iLowH, 179); //Hue (0 - 179)
 createTrackbar("HighH", "HSV", &iHighH, 179);

  createTrackbar("LowS", "HSV", &iLowS, 255); //Saturation (0 - 255)
 createTrackbar("HighS", "HSV", &iHighS, 255);

  createTrackbar("LowV", "HSV", &iLowV, 255);//Value (0 - 255)
 createTrackbar("HighV", "HSV", &iHighV, 255);

  int iLastX = -1; 
 int iLastY = -1;

  //Capture a temporary image from the camera
 Mat imgTmp;
 cap.read(imgTmp); 


 Mat imgLines = Mat::zeros( imgTmp.size(), CV_8UC3 );;
 

    while (true)
    {
        Mat imgOriginal;

        bool bSuccess = cap.read(imgOriginal); // read a new frame from video



         if (!bSuccess) 
        {
             cout << "Cannot read a frame from video stream" << endl;
             break;
        }

    Mat imgHSV;

   cvtColor(imgOriginal, imgHSV, COLOR_BGR2HSV); 
 
  Mat imgThresholded;

   inRange(imgHSV, Scalar(iLowH, iLowS, iLowV), Scalar(iHighH, iHighS, iHighV), imgThresholded); //Threshold the image
      

  erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );
  dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) ); 


  dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) ); 
  erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

  Moments oMoments = moments(imgThresholded);

   double dM01 = oMoments.m01;
  double dM10 = oMoments.m10;
  double dArea = oMoments.m00;

  
  if (dArea > 10000)
  {
   //calculate the position of the ball
   int posX = dM10 / dArea;
   int posY = dM01 / dArea;        
        
   if (iLastX >= 0 && iLastY >= 0 && posX >= 0 && posY >= 0)
   {

    imgLines.setTo(Scalar(0,0,0));
    circle(imgLines,Point(posX, posY),30, Scalar(0,255,0),2);
   // line(imgLines, Point(posX, posY), Point(iLastX, iLastY), Scalar(0,255,0), 2);
  std::async(sendData,posX,posY);
  //sendData(posX,posY);

   }

    iLastX = posX;
   iLastY = posY;
  }

  // imshow("Object Image", imgThresholded); //show the thresholded image

   imgOriginal = imgOriginal + imgLines;
  imshow("DanialEghbali Soccer Server", imgOriginal);

        if (waitKey(30) == 27) 
       {
         shutDown();
            cout << "Soccer Server Stoped" << endl;
            break; 
       }
    }

   return 0;
}
